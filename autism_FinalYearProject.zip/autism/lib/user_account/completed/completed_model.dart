import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/add_task_widget.dart';
import '/components/task2_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'completed_widget.dart' show CompletedWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CompletedModel extends FlutterFlowModel<CompletedWidget> {
  ///  State fields for stateful widgets in this page.

  // Models for task2 dynamic component.
  late FlutterFlowDynamicModels<Task2Model> task2Models;

  @override
  void initState(BuildContext context) {
    task2Models = FlutterFlowDynamicModels(() => Task2Model());
  }

  @override
  void dispose() {
    task2Models.dispose();
  }
}
