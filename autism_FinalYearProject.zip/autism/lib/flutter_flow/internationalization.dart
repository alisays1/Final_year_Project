import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'ur'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? urText = '',
  }) =>
      [enText, urText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // HomePage
  {
    '1ga1z5vr': {
      'en': 'Welcome ',
      'ur': '',
    },
    '3ktz02xo': {
      'en': 'Join Us By',
      'ur': '',
    },
    '6mw7n7q8': {
      'en': 'Sign In',
      'ur': '',
    },
    '9exq8o31': {
      'en': 'Sign Up',
      'ur': '',
    },
    '0j0kp1k5': {
      'en': 'AUTISM SUPPORT',
      'ur': '',
    },
    '36qk5u3m': {
      'en': 'Home',
      'ur': '',
    },
  },
  // Signin
  {
    'flacjuni': {
      'en': 'Autism Support',
      'ur': '',
    },
    'r706kgqa': {
      'en': 'Email',
      'ur': '',
    },
    'zis5xp56': {
      'en': 'Enter Email',
      'ur': '',
    },
    'my356k1a': {
      'en': 'Password',
      'ur': '',
    },
    'ycurqk6l': {
      'en': 'Enter Password',
      'ur': '',
    },
    'oxwxyybq': {
      'en': 'Sign In',
      'ur': '',
    },
    'ghbdkdg5': {
      'en': 'Forget Password',
      'ur': '',
    },
    'rderzd8e': {
      'en': 'Create New Account',
      'ur': '',
    },
    'rl483c3p': {
      'en': 'Sign/out',
      'ur': '',
    },
  },
  // HomePage1
  {
    '18ooidex': {
      'en': 'Personalize Recommendations',
      'ur': '',
    },
    'o5e5ef03': {
      'en': 'Exercise Recommendations',
      'ur': '',
    },
    'lhtjltcu': {
      'en': 'Lifestyle Recommendations',
      'ur': '',
    },
    '4ryrsl86': {
      'en': 'Care',
      'ur': '',
    },
    '2ty647fa': {
      'en': 'Care',
      'ur': '',
    },
  },
  // forgetPass
  {
    'uuv236g2': {
      'en': 'Enter Email to recover your Account',
      'ur': '',
    },
    'e9dygrhe': {
      'en': 'Email',
      'ur': '',
    },
    '6sd45mll': {
      'en': 'Enter Email',
      'ur': '',
    },
    'qhd5dr7m': {
      'en': 'Send Code',
      'ur': '',
    },
    'em8q0s1p': {
      'en': 'Back',
      'ur': '',
    },
    '4p7wddq3': {
      'en': 'Autism Support',
      'ur': '',
    },
    '2exq23s7': {
      'en': 'Home',
      'ur': '',
    },
  },
  // HomePage2
  {
    'vxa8z502': {
      'en': 'Shapes',
      'ur': '',
    },
    'lwiusng2': {
      'en': 'Emotion',
      'ur': '',
    },
    'vmdat9j8': {
      'en': 'Colours',
      'ur': '',
    },
    'atr0krgn': {
      'en': 'Fruits',
      'ur': '',
    },
    'y8byla34': {
      'en': 'Activities',
      'ur': '',
    },
    '6ed0px0e': {
      'en': 'Activities',
      'ur': '',
    },
  },
  // Home
  {
    'q0eg9vwx': {
      'en': 'Profile',
      'ur': '',
    },
    'maaewb6f': {
      'en': 'Update Profile',
      'ur': '',
    },
    'h1e83v9e': {
      'en': 'Gender',
      'ur': '',
    },
    'ma7vxglc': {
      'en': 'Weight',
      'ur': '',
    },
    '6q47ycgj': {
      'en': 'Height',
      'ur': '',
    },
    '266eag50': {
      'en': 'Log Out',
      'ur': '',
    },
    'nse6tip9': {
      'en': 'Delete Acoount',
      'ur': '',
    },
    'nofwy8k2': {
      'en': 'Profile',
      'ur': '',
    },
  },
  // SignUp
  {
    'jg8dkebb': {
      'en': 'Click here to upload Photo',
      'ur': '',
    },
    'cjvqvel9': {
      'en': 'Enter Details of Kid',
      'ur': '',
    },
    '9qsbue45': {
      'en': 'Full  Name',
      'ur': '',
    },
    '9id5dldf': {
      'en': 'Full  Name',
      'ur': '',
    },
    'vlvs5gsz': {
      'en': 'Email',
      'ur': '',
    },
    '6xc32s65': {
      'en': 'Enter Email',
      'ur': '',
    },
    'l70rzzxk': {
      'en': ' Password',
      'ur': '',
    },
    'sk8pk3e5': {
      'en': 'Create Password',
      'ur': '',
    },
    'z2rg36zp': {
      'en': ' Password',
      'ur': '',
    },
    'ygykagql': {
      'en': 'Retype Password',
      'ur': '',
    },
    '1jtyoblo': {
      'en': 'Date of Birth',
      'ur': '',
    },
    'qwq55zdo': {
      'en': 'Birthday',
      'ur': '',
    },
    '9gczjxxd': {
      'en': 'Weight',
      'ur': '',
    },
    'wmjtd7f2': {
      'en': 'in kg',
      'ur': '',
    },
    '0miid3xk': {
      'en': 'Height',
      'ur': '',
    },
    'tu49bzl4': {
      'en': 'in cm',
      'ur': '',
    },
    'n3j2xia5': {
      'en': 'Male',
      'ur': '',
    },
    'eouqz27f': {
      'en': 'Female',
      'ur': '',
    },
    'xrripgrb': {
      'en': 'Gender',
      'ur': '',
    },
    'hfv8mo64': {
      'en': 'Search for an item...',
      'ur': '',
    },
    'qcsp7a67': {
      'en': 'Create Account',
      'ur': '',
    },
    'e5rnu835': {
      'en': 'Create New Accountant',
      'ur': '',
    },
    'p0kvjomj': {
      'en': 'Home',
      'ur': '',
    },
  },
  // PerRecomend
  {
    'ntq4rwjv': {
      'en': 'Daily Sensory Play',
      'ur': '',
    },
    '6a2ozxyc': {
      'en': 'Structure\nPhysical Activities',
      'ur': '',
    },
    'unodhqtu': {
      'en': 'Outdoor Activities',
      'ur': '',
    },
    'ol2zedqg': {
      'en': 'Skils',
      'ur': '',
    },
    'm7xmgv5x': {
      'en': 'Exercise games',
      'ur': '',
    },
    'bcebihco': {
      'en': 'Back',
      'ur': '',
    },
    'om5dapix': {
      'en': 'Personal Recommendations',
      'ur': '',
    },
    'wbvd28ox': {
      'en': 'Home',
      'ur': '',
    },
  },
  // PerRecomendCopy
  {
    '0gslrgnl': {
      'en': 'These are the Recommendations related to Lifestyle',
      'ur': '',
    },
    'qz8psxjw': {
      'en': 'Consistent Routine',
      'ur': '',
    },
    't5axsktk': {
      'en': 'Healthy Eating',
      'ur': '',
    },
    'l2xl62ff': {
      'en': 'Breathing Exercise',
      'ur': '',
    },
    'ih4f7a9z': {
      'en': 'Sleep Hygiene',
      'ur': '',
    },
    'muc59hju': {
      'en': 'Social Interection',
      'ur': '',
    },
    '8vuy30ym': {
      'en': 'Back',
      'ur': '',
    },
    'my0ufkzl': {
      'en': 'Personal Recommendations',
      'ur': '',
    },
    'w9uau4xj': {
      'en': 'Home',
      'ur': '',
    },
  },
  // ActivityShapes
  {
    '8vdj5mv7': {
      'en': 'Squar',
      'ur': '',
    },
    '6mavbrpf': {
      'en': 'Triangle',
      'ur': '',
    },
    'aq4vmcd9': {
      'en': 'Rectangle',
      'ur': '',
    },
    '3xr92xvf': {
      'en': 'Circle',
      'ur': '',
    },
    'sjknw2zd': {
      'en': 'Heart',
      'ur': '',
    },
    'kfaqrb48': {
      'en': 'Back',
      'ur': '',
    },
    'xpuqwhq2': {
      'en': 'Shape Activity',
      'ur': '',
    },
    'e10f17e3': {
      'en': 'Home',
      'ur': '',
    },
  },
  // ActivityEmotions
  {
    'chf04nfy': {
      'en': 'Back',
      'ur': '',
    },
    'ju97n92f': {
      'en': 'Emotion Activity',
      'ur': '',
    },
    'vnbcqvy7': {
      'en': 'Happy',
      'ur': '',
    },
    '43cts1m5': {
      'en': 'Sad',
      'ur': '',
    },
    'fuf875d1': {
      'en': 'Crying',
      'ur': '',
    },
    'q3u1m6rz': {
      'en': 'Serious',
      'ur': '',
    },
    'x3gx7a1l': {
      'en': 'Fun',
      'ur': '',
    },
    'bza7fvad': {
      'en': 'Home',
      'ur': '',
    },
  },
  // ActivityColor
  {
    'wvj06j6v': {
      'en': 'Red',
      'ur': '',
    },
    '822jozgk': {
      'en': 'Yellow',
      'ur': '',
    },
    'liqrtmy8': {
      'en': 'Green',
      'ur': '',
    },
    'mfnhltvl': {
      'en': 'Black',
      'ur': '',
    },
    '418w9pn3': {
      'en': 'Blue',
      'ur': '',
    },
    '1o3i0tx1': {
      'en': 'Back',
      'ur': '',
    },
    'u9pfsaxk': {
      'en': 'Color Activity',
      'ur': '',
    },
    'v223tkh4': {
      'en': 'Home',
      'ur': '',
    },
  },
  // ActivityFruits
  {
    'yz3hswc8': {
      'en': 'Back',
      'ur': '',
    },
    '4ejxy7m5': {
      'en': 'Fruits Activity  ',
      'ur': '',
    },
    'nub8e5r3': {
      'en': 'Apple',
      'ur': '',
    },
    'j8bdxyh9': {
      'en': 'Mango',
      'ur': '',
    },
    '3z6dgfyf': {
      'en': 'Banana',
      'ur': '',
    },
    '6qiqty4c': {
      'en': 'Strawberry',
      'ur': '',
    },
    'bgjsuu6j': {
      'en': 'Grapes',
      'ur': '',
    },
    '7az2x18v': {
      'en': 'Home',
      'ur': '',
    },
  },
  // UpdatePassword
  {
    'cjv2td4n': {
      'en': 'Change Password',
      'ur': '',
    },
    'fie0id2b': {
      'en': 'Password',
      'ur': '',
    },
    '9tzjpcsx': {
      'en': 'Enter Password',
      'ur': '',
    },
    'znzcdw17': {
      'en': 'Confirm Password',
      'ur': '',
    },
    'n5yu0kjn': {
      'en': 'Reenter Password',
      'ur': '',
    },
    'izxcyctf': {
      'en': 'Update Password',
      'ur': '',
    },
    '2csioy4d': {
      'en': 'Back',
      'ur': '',
    },
    '4cglhhhu': {
      'en': 'Autism Support',
      'ur': '',
    },
    'zt1k4k1l': {
      'en': 'Home',
      'ur': '',
    },
  },
  // VerifyEmail
  {
    'nv4bd8tu': {
      'en': 'Send Code',
      'ur': '',
    },
    '4n8vobvp': {
      'en': 'Back',
      'ur': '',
    },
    'fbkpal8y': {
      'en': 'Verify My  Email',
      'ur': '',
    },
    'rm4jtg8k': {
      'en': 'Home',
      'ur': '',
    },
  },
  // DeleteAccount
  {
    'bm8ozpah': {
      'en': 'Delete Account',
      'ur': '',
    },
    '70wwaed6': {
      'en': 'Delete Account',
      'ur': '',
    },
    '3h2t7boq': {
      'en': 'Back',
      'ur': '',
    },
    'qce0pds3': {
      'en': 'Autism Support',
      'ur': '',
    },
    '9r602rek': {
      'en': 'Home',
      'ur': '',
    },
  },
  // task
  {
    '4r5p8jwz': {
      'en': 'Tasks',
      'ur': '',
    },
    '1khsjz4w': {
      'en': 'Task',
      'ur': '',
    },
  },
  // UpdateProfileCopy2
  {
    'ecy456zd': {
      'en': 'You can change your information\nby changing the entries',
      'ur': '',
    },
    'dj1t9eed': {
      'en': 'Name',
      'ur': '',
    },
    'eglo84wu': {
      'en': 'Weight',
      'ur': '',
    },
    '40vrzwa5': {
      'en': 'Height',
      'ur': '',
    },
    '8ags366o': {
      'en': 'Male',
      'ur': '',
    },
    '9yocfwf2': {
      'en': 'Female',
      'ur': '',
    },
    '8qcr2gz7': {
      'en': 'Gender',
      'ur': '',
    },
    'kpafh0se': {
      'en': 'Search for an item...',
      'ur': '',
    },
    'f0dpheog': {
      'en': 'Update',
      'ur': '',
    },
    'ouypxzx1': {
      'en': 'Back',
      'ur': '',
    },
    '06pvzknb': {
      'en': 'Update Profile',
      'ur': '',
    },
    'ikrzmthh': {
      'en': 'Home',
      'ur': '',
    },
  },
  // completed
  {
    '2xrji5df': {
      'en': 'Tasks',
      'ur': '',
    },
    'k9z82z27': {
      'en': 'Task',
      'ur': '',
    },
  },
  // UpdateTask
  {
    's946dj5t': {
      'en': ' Task',
      'ur': '',
    },
    'lbbxnyhe': {
      'en': 'Title',
      'ur': '',
    },
    '24o4v4d2': {
      'en': 'Details',
      'ur': '',
    },
    'dx8dlok7': {
      'en': 'Add Task',
      'ur': '',
    },
    '6wtk1w4p': {
      'en': 'Delete Task',
      'ur': '',
    },
    'wddkpjb0': {
      'en': 'Add Task',
      'ur': '',
    },
    'w6llsqy2': {
      'en': 'Back',
      'ur': '',
    },
    'jrwrjva0': {
      'en': 'Task',
      'ur': '',
    },
  },
  // DeleteAccountC
  {
    '6uevst2z': {
      'en': 'Delete Account',
      'ur': '',
    },
    'dazn24kj': {
      'en': 'This action cannot be undone',
      'ur': '',
    },
    'e7pbp58v': {
      'en': 'By deleting your account, your all data will be deleted',
      'ur': '',
    },
    '0j5gwc03': {
      'en': 'Delete Account',
      'ur': '',
    },
    '3pssxsey': {
      'en': 'Cancel',
      'ur': '',
    },
  },
  // AddTask
  {
    'apo0ffiq': {
      'en': 'Add Task',
      'ur': '',
    },
    'bkug9ikj': {
      'en': 'Title',
      'ur': '',
    },
    'o72rsihh': {
      'en': 'Details',
      'ur': '',
    },
    'x7u6nd8t': {
      'en': 'Add Task',
      'ur': '',
    },
  },
  // AddTaskCopy
  {
    'ru0sfdgp': {
      'en': 'Add Task',
      'ur': '',
    },
    'kuuquqj0': {
      'en': 'Title',
      'ur': '',
    },
    '9bfdr767': {
      'en': 'Details',
      'ur': '',
    },
    'eubdyfmf': {
      'en': 'Add Task',
      'ur': '',
    },
  },
  // Miscellaneous
  {
    '0kzajvx4': {
      'en': '',
      'ur': '',
    },
    'n3dcs503': {
      'en': '',
      'ur': '',
    },
    'udvjnpl3': {
      'en': '',
      'ur': '',
    },
    'qfvnifxr': {
      'en': '',
      'ur': '',
    },
    'x30gmwzc': {
      'en': '',
      'ur': '',
    },
    '2tefyd1h': {
      'en': '',
      'ur': '',
    },
    'q4vdfkjn': {
      'en': '',
      'ur': '',
    },
    'alny55a2': {
      'en': '',
      'ur': '',
    },
    'u9p46l7q': {
      'en': '',
      'ur': '',
    },
    '5dfne1fh': {
      'en': '',
      'ur': '',
    },
    '1ko87nmt': {
      'en': '',
      'ur': '',
    },
    'uj6kqwbd': {
      'en': '',
      'ur': '',
    },
    'yfyzbr4q': {
      'en': '',
      'ur': '',
    },
    'trrq6akd': {
      'en': '',
      'ur': '',
    },
    'k2s1oxba': {
      'en': '',
      'ur': '',
    },
    '33e5j9bh': {
      'en': '',
      'ur': '',
    },
    'y4ic5rnm': {
      'en': '',
      'ur': '',
    },
    '84eqf0qr': {
      'en': '',
      'ur': '',
    },
    'fm4ntjok': {
      'en': '',
      'ur': '',
    },
    '0zryjpeo': {
      'en': '',
      'ur': '',
    },
    'neeo0s75': {
      'en': '',
      'ur': '',
    },
    'clpnkrnw': {
      'en': '',
      'ur': '',
    },
    'aofx1ccu': {
      'en': '',
      'ur': '',
    },
    'epnkvorq': {
      'en': '',
      'ur': '',
    },
    'zp5aqsmh': {
      'en': '',
      'ur': '',
    },
    'gmezppp6': {
      'en': '',
      'ur': '',
    },
    '5e7ok26x': {
      'en': '',
      'ur': '',
    },
  },
].reduce((a, b) => a..addAll(b));
