import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDP5sokfT_-216XFpKt6L1HP87eQLECgJ4",
            authDomain: "autism-8zxypv.firebaseapp.com",
            projectId: "autism-8zxypv",
            storageBucket: "autism-8zxypv.appspot.com",
            messagingSenderId: "589813460674",
            appId: "1:589813460674:web:c15cc77899c2bf5825d55b"));
  } else {
    await Firebase.initializeApp();
  }
}
